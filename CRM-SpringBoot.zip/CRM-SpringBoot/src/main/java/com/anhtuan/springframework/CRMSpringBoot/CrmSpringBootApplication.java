package com.anhtuan.springframework.CRMSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrmSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrmSpringBootApplication.class, args);
	}
}
